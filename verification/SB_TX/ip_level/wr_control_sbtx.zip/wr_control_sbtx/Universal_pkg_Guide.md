# `Universal_pkg.sv` — Contents & Verification Usage Guide

> **Source File:** [Universal_pkg.sv](file:///d:/University/Digital_Verification/UCIe_GP/git/ucie-phy-dv/verification/SB_TX/ip_level/wr_control_sbtx/RTL/Universal_pkg.sv)

`Universal_pkg` is the shared SystemVerilog package for the UCIe PHY RTL and verification environment. It centralizes sideband packet field offsets, opcodes, message codes, state encodings, pre-built 64-bit protocol messages, configuration structs, and debug/verification helpers.

---

## 1. Contents Breakdown of `Universal_pkg.sv`

### 1.1 Sideband Packet Bit-Field Lengths & Offsets (Lines 3–24, 600)
Defines the exact bit positions of fields inside both a **32-bit phase (`lp_cfg[31:0]`)** and an assembled **64-bit Sideband Header (`[63:0]`)**:

| Slice / Offset | Constant | Width | Meaning |
| :--- | :--- | :---: | :--- |
| `[4:0]` | `opcode_offset = 0` | `OPCODE_LENGTH = 5` | Packet `OPCODES` |
| `[21:14]` | `msgcode_offset = 14` | `MSGCODE_LENGTH = 8` | Message code (for Message opcodes) |
| `[21:14]` | `be_offset = 14` | `BE_LENGTH = 8` | Byte Enables (for RAR opcodes) |
| `[26:22]` | `tag_offset = 22` | `TAG_LENGTH = 5` | Transaction tag |
| `[26:24]` | `dstid_offset_32 = 24` | `DST_ID_LENGTH = 3` | 32-bit phase offset for `dstid` (Header Phase 2 `[26:24]`) |
| `[31:29]` | `srcid_offset = 29` | `SRC_ID_LENGTH = 3` | Source ID (`src_D2D = 3'b001`, `src_PHY = 3'b010`) |
| `[30]` (Ph2) | `cp_offset_32 = 30` | `1` | Control Parity bit in 32-bit Header Phase 2 |
| `[31]` (Ph2) | `dp_offset_32 = 31` | `1` | Data Parity bit in 32-bit Header Phase 2 |
| `[34:32]` | `status_offset = 32` | `STATUS_LENGTH = 3` | Completion status (`Comp_Status`) |
| `[55:32]` | `addr_offset = 32` | `ADDR_LENGTH = 24` | RAR Address (or `{MsgInfo[55:40], MsgSubcode[39:32]}`) |
| `[58:56]` | `dstid_offset_64 = 56` | `DST_ID_LENGTH = 3` | 64-bit Header offset for `dstid` (`3'b110` = PHY) |
| `[62]` | `cp_offset_64 = 62` | `1` | Control Parity bit in 64-bit Header |
| `[63]` | `dp_offset_64 = 63` | `1` | Data Parity bit in 64-bit Header |

Full 64-bit Message Header format (Line 600):
```text
{ dp[63], cp[62], rsvd[61:59], dstid[58:56], MsgInfo[55:40], MsgSubcode[39:32],
  srcid[31:29], rsvd[28:22], MsgCode[21:14], rsvd[13:5], opcode[4:0] }
```

---

### 1.2 Packet Opcodes & Classification Arrays (Lines 31–68, 375–392)
* **`OPCODES` (`logic [4:0]`):** 19 sideband opcodes:
  * **32-bit RARs:** `Memory_Read_32b` (`5'b00000`), `Memory_Write_32b` (`5'b00001`), `DMS_Register_Read_32b` (`5'b00010`), `DMS_Register_Write_32b` (`5'b00011`), `Configuration_Read_32b` (`5'b00100`), `Configuration_Write_32b` (`5'b00101`).
  * **64-bit RARs:** `Memory_Read_64b` (`5'b01000`), `Memory_Write_64b` (`5'b01001`), `DMS_Register_Read_64b` (`5'b01010`), `DMS_Register_Write_64b` (`5'b01011`), `Configuration_Read_64b` (`5'b01100`), `Configuration_Write_64b` (`5'b01101`).
  * **Completions:** `Completion_Without_Data` (`5'b10000`), `Completion_With_32b_Data` (`5'b10001`), `Completion_With_64b_Data` (`5'b11001`).
  * **Messages & MPM:** `Message_Without_Data` (`5'b10010`), `Message_With_64b_Data` (`5'b11011`), `MPM_Without_Data` (`5'b10111`), `MPM_With_Data` (`5'b11000`).
* **`Comp_Status` (`logic [2:0]`):** `SC = 3'b000`, `UR = 3'b001`, `CA = 3'b100`, `Stall = 3'b111`.
* **Built-in Opcode Queues:**
  * **`CRD[]` (Lines 375–379):** The 10 opcodes that consume a D2D/RDI credit (all Memory/Config Reads & Writes + `Message_Without_Data` + `Message_With_64b_Data`). Excludes Completions, DMS, and MPM.
  * **`PHASE[]` (Lines 381–392):** The 10 opcodes that carry a 64-bit data payload (4-phase packets: 2 header phases + 2 data phases).

---

### 1.3 Message Codes, Subcodes & Packed Payloads (Lines 53–61, 121–278, 729–822)
* **`MSGCODES` (`logic [7:0]`, Lines 53–61):** Subset of 7 D2D/RDI link management and parity feature codes (`8'h01`–`8'h07`):
  * `RDI_LINK_MANAGEMENT_REQ/RESP` (`8'h01`/`8'h02`)
  * `D2D0_LINK_MANAGEMENT_REQ/RESP` (`8'h03`/`8'h04`)
  * `D2D1_LINK_MANAGEMENT_REQ/RESP` (`8'h05`/`8'h06`)
  * `D2D_Parity_Feature_Req` (`8'h07`)
* **`msgcode_e` (`logic [7:0]`, Lines 203–231):** Full 27-entry enum covering `nop_credit` (`8'h00`), RDI/D2D link management (`8'h01`–`8'h08`), `err_msg` (`8'h09`), `vendor_defined` (`8'hFF`), and PHY training request/response/done codes (`8'h81`–`8'hEA`).
* **Subcode / MsgInfo Enums & Union (Lines 134–142, 233–278):**
  * `rdi_active`, `rdi_linkreset`, `rdi_linkerror`, `rdi_retrain`, `rdi_disable`, `nop_crd_reserved` (plus `rdi_msg_subcodes` array).
  * `msgsub_msginfo_enum1` (point tests / eye sweeps), `sbinit_msgcode_msginfo` (`SBINIT_done`, `SBINIT_out_of_Reset`), `msgsub_msginfo_enum2` (`MBTRAIN_*`), combined in `msgsub_msginfo_union`.
* **Packed Config Structs (Lines 730–822):**
  * `tx_init_d2c_msginfo_t`, `phy_config_t`, `tx_init_config_t` along with preset parameter structs (`D_TO_C_LFSR`, `D_TO_C_DEFAULT`, `D_TO_C_PERLANE`, `PHY_CONFIG_REQ`, `PHY_CONFIG_RESP`, `msginfo_succ`).

---

### 1.4 State Machine Encodings (Lines 78–119, 321–325, 347–373)
* **`LTSM_state` (3-bit) & `LTSM_states` (5-bit):** `RESET`, `SBINIT`, `MBINIT` sub-states, `MBTRAIN` sub-states, `LINKINIT`, `ACTIVE`, `PHYRETRAIN`, `TRAINERROR`.
* **`MBINIT_states` / `MBTRAIN_states` / `RDI_states` / `phase_t`:** Sub-state and RDI transition encodings.
* **`States` (2-bit SBTX encoding):** `RESET_SBINIT = 2'b10`, `active = 2'b00`, `Other_State = 2'b01`.

---

### 1.5 Pre-Built 64-Bit Messages & Debug Decoder (Lines 154–200, 286–318, 483–726, 833–1036)
* **`LINK_MGMT_RDI_*` (`bit [61:0]`):** Pre-assembled 62-bit RDI link management messages (without `CP`/`DP` bits `[63:62]`), grouped into `req_msgs`, `rsp_msgs`, and `all_msgs`.
* **`SBINIT_out_of_Reset_Message`:** `64'h0600010000244012`.
* **`message_array[]` (Lines 602–709):** Large array of pre-built 64-bit PHY training messages (`SBINIT_*`, `MBINIT_*`, `MBTRAIN_*`, `PHYRETRAIN_*`, `TRAINERROR_*`), plus `msgs_before_tx_init[]` and `msgs_before_rx_init[]`.
* **`enum_t` and `msg2enum(logic [63:0] val)` (Lines 833–1036):** Maps a raw 64-bit sideband message into a human-readable `enum_t` name (or `ZEROS` / `OTHER`) for logging and debugging.

---

### 1.6 Timing, Lane & Global Verification Variables (Lines 25–26, 70–76, 282–285, 327–345, 396–413)
* **Constants:** `DATA_WIDTH = 64`, `CHUNK_WIDTH = 32`, `ADDR_WIDTH = 24`, `SB_CLK_FREQ_HZ = 800_000_000`, `MS_TO_CLK = 1_000`, `PATTERN_CYCLES = 4`, `TIMER_CYCLES = 8`, `NUM_LANES = 16`, etc.
* **Global Verification Flags:** `start_sbtx_compare`, `start_sbrx_compare`, `start_mbtx_compare`, `rdi_credits`, `d2d_err`, `end_of_seq_sbtx`, etc. *(Intended for full-PHY integration coordination; avoid relying on global flags in standalone IP-level UVM tests.)*

---

## 2. How to Use `Universal_pkg` in Verification

### 2.1 In Sequence Items & Constraints (`wr_control_sbtx_sequence_item.svh`)
1. **Use `OPCODES` and `PHASE[]` for Legal Framing:**
   * Randomize an `OPCODES` field `opcode` and constrain `lp_cfg[4:0]` on Header Phase 1 to match `opcode`.
   * Use `opcode inside {Universal_pkg::PHASE}` to automatically decide whether to generate **2 phases** (Header-only) or **4 phases** (Header + 64-bit Data).
   * For 32-bit data opcodes (`Memory_Write_32b`, `Configuration_Write_32b`, `Completion_With_32b_Data`), constrain `Data Phase 2 == 32'h0` per UCIe Spec Figure 3-15.
2. **Use Offsets to Pack Headers & Compute Parity (`CP` / `DP`):**
   * Construct Header Phase 1 and Header Phase 2 cleanly using `opcode_offset`, `msgcode_offset`, `be_offset`, `tag_offset`, `srcid_offset`, `dstid_offset_32`, `cp_offset_32`, and `dp_offset_32`.
   * Calculate valid parity bits using `cp_offset_32` and `dp_offset_32` (and add an `inject_cp_err` / `inject_dp_err` knob to intentionally flip them for negative testing).
3. **Use `MSGCODES` / `msgcode_e` for `Req_Resp_Marker` Coverage:**
   * Constrain `lp_cfg[msgcode_offset +: MSGCODE_LENGTH]` on `Message_Without_Data` / `Message_With_64b_Data` to hit both D2D `Req_Resp` codes (`8'h03`–`8'h07`) and non-`Req_Resp` codes (`8'h00`, `8'h09`, `8'hFF`), plus RARs whose `be[7:0]` happens to equal `8'h03`–`8'h07`.

### 2.2 In Your Golden Reference Model (`ref_model`)
* Import `Universal_pkg::*;` so the reference model uses the **exact same** `OPCODES`, `MSGCODES` / `msgcode_e`, and bit offsets (`opcode_offset`, `msgcode_offset`, `cp_offset_32`, `dp_offset_32`) without magic numbers.
* Use `PHASE` (or the explicit opcode list) to determine packet length and `Data_Marker`.
* Use `Comp_Status` / Completion opcodes (`Completion_Without_Data`, `Completion_With_32b_Data`, `Completion_With_64b_Data`) to drive `Comp_Marker` and gate `Error_Handler`.

### 2.3 In Your Scoreboard, Assertions (SVA), & Coverage (`subscriber`)
* **Functional Coverage:** Create coverpoints on `OPCODES` (all 19 opcodes, or the supported subset), `MSGCODES`, `srcid` (`src_D2D` vs `src_PHY`), `CRD[]` vs non-credit opcodes, and cross-coverage of `OPCODES x {valid, CP_err, DP_err, both_err}`.
* **SVA:** Reuse `PHASE` or `OPCODES` in `wr_control_sbtx_sva.sv` instead of hardcoding `5'b...` literals in `has_data_opcode()`.
* **Readable Debug Logs:** Call `Universal_pkg::msg2enum(Interface_Message)` in monitor/scoreboard `uvm_info` messages to print symbolic names for known PHY/RDI messages instead of raw 64-bit hex.

### 2.4 Things to Watch Out For When Using `Universal_pkg`
* **Note the bit-width nuance on `dstid` vs `addr`:** In 64-bit headers, `addr_offset = 32` (`[55:32]`) and `dstid_offset_64 = 56` (`[58:56]`). In 32-bit Header Phase 2, `dstid_offset_32 = 24` (`[26:24]`), which matches `56 - 32 = 24`.
* **Do not drive `LINK_MGMT_RDI_*` directly without adding `CP`/`DP`:** Those constants are `62` bits (`[61:0]`); you must prepend `{dp, cp}` at `[63:62]` before driving them as a 64-bit header.
* **Avoid using global `bit` variables in IP-level UVM:** Signals like `disable_compare`, `start_sbtx_compare`, and `rdi_credits` are package-level globals for full-chip tests; keep IP-level scoreboards self-contained using UVM `uvm_config_db` / analysis ports.

