# `WR_Control_SBTX` — Detailed Verification Plan (Testcases)

| Test ID | Test | Priority | Feature | Verification Method | Description | Coverage |
| :--- | :--- | :---: | :--- | :---: | :--- | :--- |
| `TC_01` | `wr_control_sbtx_reset_test` | High | Reset & Initialization `[Corner Case]` | Directed | Asserts `RST_n = 0` at power-on and while `lp_cfg_vld = 1`, verifies all outputs clear to `'0`, then sends a valid packet immediately after reset release. | `cg_reset` |
| `TC_02` | `wr_control_sbtx_rar_cr_test` | High | RAR Framing & Markers | Constrained-Random | Randomizes across all 8 RAR opcodes (32b/64b Memory & Config Reads/Writes) with valid parity; verifies 2-phase vs. 4-phase assembly, 32-bit upper data zero-padding, `Reg_Acc_Marker`, `Data_Marker`, and `Reg_Acc_Data_Marker`. | `cg_opcodes`, `cg_markers`, `cx_opcode_markers` |
| `TC_03` | `wr_control_sbtx_msg_cr_test` | High | Sideband Messages & Req/Resp | Constrained-Random | Randomizes `SB_MSG_NO_DATA` and `SB_MSG_WITH_64B_DATA` across all `req_resp_msgcode_e` and `non_req_resp_msgcode_e` values; verifies `Req_Resp_Marker` and `Data_Marker`. | `cg_msgcodes`, `cx_msg_opcode_code` |
| `TC_04` | `wr_control_sbtx_comp_cr_test` | High | Completion Handling | Constrained-Random | Randomizes `SB_CMPL_NO_DATA`, `SB_CMPL_WITH_32B_DATA`, and `SB_CMPL_WITH_64B_DATA` (both valid and parity-errored); verifies `Comp_Marker`, `Data_Marker`, and `Error_Handler == 0` on Completion errors. | `cg_opcodes`, `cx_comp_parity` |
| `TC_05` | `wr_control_sbtx_parity_err_cr_test` | High | CP & DP Parity Detection | Constrained-Random | Randomizes all 13 opcodes with constrained `CP`-only, `DP`-only (including 2-phase `DP = 1`), and simultaneous `CP + DP` errors; verifies `UIE`, `Error_Handler`, and FIFO write blocking. | `cg_parity`, `cx_opcode_parity` |
| `TC_06` | `wr_control_sbtx_b2b_pipeline_cr_test` | High | Back-to-Back Pipelining `[Corner Case]` | Constrained-Random | Constrains `num_idle_cycles == 0` across randomized 2-phase and 4-phase packets (valid and errored) to hit all consecutive transitions (`2->2`, `2->4`, `4->2`, `4->4`) with zero bubbles. | `cg_pipeline`, `cx_b2b_len_trans` |
| `TC_07` | `wr_control_sbtx_mid_pkt_rst_cr_test` | Medium | Mid-Packet Async Reset `[Corner Case]` | Directed+CR | Randomizes 2-phase and 4-phase packets while asserting `RST_n = 0` mid-packet after Phase 0, Phase 1, and Phase 2; verifies partial packet abort and clean recovery on the next packet. | `cg_reset`, `cx_rst_phase` |
| `TC_08` | `wr_control_sbtx_corner_cases_cr_test` | Medium | BE/MsgCode Collision & Reserved Opcode `[Corner Case]` | Directed+CR | Constrains RAR `be[7:0]` to collide with `req_resp_msgcode_e` (`Req_Resp_Marker` must stay `0`), injects reserved opcodes (`UIE = 1`, `FIFO_WR = 0`), and varies inter-packet `lp_cfg_vld` idle gaps. | `cg_corners`, `cg_opcodes` |
| `TC_09` | `wr_control_sbtx_full_rand_stress_test` | High | Full Randomized Regression | Constrained-Random | Multi-seed weighted constrained-random stress sequence mixing all 13 opcodes, all msgcodes, parity errors, back-to-back bursts, idle gaps, and occasional resets for full coverage closure. | All Covergroups |

---

# `WR_Control_SBTX` — Functional & Code Coverage Closure Plan

| Covergroup | Category ID | Coverpoint / Cross | Bins & Sampling Intent (`iff`) | Target Goal |
| :--- | :---: | :--- | :--- | :---: |
| `cg_opcodes` | `COV_01` | `cp_opcode` | 13 bins for all valid `sb_opcode_e` + 1 bin for reserved opcodes (`iff (RST_n && lp_cfg_vld)` on Header Phase 0). | `100%` |
| `cg_msgcodes` | `COV_02` | `cp_msgcode` | Bins for all `req_resp_msgcode_e` and `non_req_resp_msgcode_e` (`iff (RST_n && opcode inside {msg_packets})`). | `100%` |
| `cg_msgcodes` | `COV_03` | `cx_msg_opcode_code` | Cross of `{SB_MSG_NO_DATA, SB_MSG_WITH_64B_DATA}` x `{req_resp, non_req_resp}`. | `100%` |
| `cg_markers` | `COV_04` | `cp_markers` | Individual 0/1 toggle bins on `Data_Marker`, `Reg_Acc_Marker`, `Reg_Acc_Data_Marker`, `Comp_Marker`, `Req_Resp_Marker` (`iff (RST_n && FIFO_WR)`). | `100%` |
| `cg_markers` | `COV_05` | `cx_opcode_markers` | Cross of `cp_opcode` x expected marker combinations on Header output cycle (`iff (RST_n && FIFO_WR)`). | `100%` |
| `cg_parity` | `COV_06` | `cp_parity_err` | 4 bins: `{clean, cp_only, dp_only, cp_and_dp}` (`iff (RST_n)` at packet completion). | `100%` |
| `cg_parity` | `COV_07` | `cx_opcode_parity` | Cross of packet category `{RAR_2ph, RAR_4ph, COMP_2ph, COMP_4ph, MSG_2ph, MSG_4ph}` x `cp_parity_err`. | `100%` |
| `cg_parity` | `COV_08` | `cp_err_outputs` | Bins for `(UIE=1, Error_Handler=1)` (non-comp error) and `(UIE=1, Error_Handler=0)` (comp error). | `100%` |
| `cg_pipeline` | `COV_09` | `cx_b2b_len_trans` | Back-to-back (`num_idle_cycles == 0`) transition bins: `2ph->2ph`, `2ph->4ph`, `4ph->2ph`, `4ph->4ph`. | `100%` |
| `cg_pipeline` | `COV_10` | `cp_idle_gaps` | Inter-packet idle cycle bins: `0` (back-to-back), `1`, `[2:3]`. | `100%` |
| `cg_reset` | `COV_11` | `cx_rst_phase` | Reset asserted (`RST_n == 0`) during `{Idle, HP0, HP1, DP0, DP1}` and with `lp_cfg_vld == 1`. | `100%` |
| `cg_corners` | `COV_12` | `cp_rar_be_collision` | RAR packet whose `be[7:0]` equals a `req_resp_msgcode_e` value (confirming `Req_Resp_Marker == 0`). | `100%` |

### RTL Code Coverage Targets

| Code Metric | Target | Verification Closure Notes |
| :--- | :---: | :--- |
| Statement (s) | `100%` (`1.0`) | All executable lines in `WR_Control_SBTX.sv` hit across regression. |
| Branch (b) | `100%` (`1.0`) | All `if`/`else` and `case` branches (2-phase, 4-phase, parity pass/fail, reset) exercised. |
| Condition (c) | `100%` (`1.0`) | All sub-conditions of `CP`/`DP` error and completion gating hit independently. |
| Expression (e) | `100%` (`1.0`) | Full expression truth tables for parity XOR and `Error_Handler` logic. |
| Toggle (t) | `100%` (`1.0`) | All 32-bit `lp_cfg` and 64-bit `Interface_Message` bits toggle `0->1` and `1->0` in `TC_09`. |

---

# `WR_Control_SBTX` — Verification Metrics & Closure Dashboard

| Metric | Target | Current | Status | Notes |
| :--- | :---: | :---: | :---: | :--- |
| Planned Tests | `9` | `9` | Planned | 1-to-1 mapping to UVM tests (`TC_01`–`TC_09`). |
| Constrained-Random & Hybrid Ratio | `0.85` (`85%`) | `0.89` (`8/9`) | Meets Target | 6 Constrained-Random + 2 Directed+CR + 1 Directed test. |
| Corner Case Tests Planned | `4` | `4` | Tagged | `TC_01`, `TC_06`, `TC_07`, `TC_08` tagged with `[Corner Case]`. |
| Executed Tests | `9` | `0` | Not Started | Update after regression execution. |
| Passed Tests | `9` | `0` | Not Started | Update after regression execution. |
| Functional Coverage | `1.0` (`100%`) | `0` | Not Started | Merged functional coverage across all 9 tests. |
| Code Coverage (`bcest`) | `1.0` (`100%`) | `0` | Not Started | Merged RTL statement/branch/cond/expr/toggle coverage. |
| Uncovered Features | `0` | `0` | Closed | All spec features mapped to tests and coverpoints. |
| Open Bugs | `0` | `0` | Clean | Track RTL/spec mismatches flagged by golden `ref_model`. |
| Regression Stability (Multi-Seed) | `1.0` (`100%`) | `0` | Not Started | Run `TC_02`–`TC_09` across multiple seeds. |

